
var gameState=0
function preload(){
girlAn=loadAnimation("assets/girl/g1.png","assets/girl/g2.png","assets/girl/g3.png","assets/girl/g4.png",
"assets/girl/g5.png","assets/girl/g6.png","assets/girl/g7.png","assets/girl/g8.png","assets/girl/g9.png","assets/girl/g10.png");
bg1=loadAnimation("assets/background1.jpg")
bg2=loadAnimation("assets/background2.jpg")
bg3=loadAnimation("assets/Dungen.jpg")
sound1=loadSound("assets/scary_bells.mp3")
sound2=loadSound("assets/bonus_room_blitz.mp3")
sound3=loadSound("assets/knight.mp3")
coinSound=loadSound("assets/mario_coin_tone.mp3")
gemImage=loadAnimation("assets/gem/frame_01_delay-0.05s.png","assets/gem/frame_02_delay-0.05s.png",
"assets/gem/frame_03_delay-0.05s.png","assets/gem/frame_04_delay-0.05s.png","assets/gem/frame_05_delay-0.05s.png","assets/gem/frame_06_delay-0.05s.png")
coinsImg=loadAnimation("assets/coin/c1.png","assets/coin/c2.png","assets/coin/c3.png","assets/coin/c4.png",
"assets/coin/c5.png","assets/coin/c6.png","assets/coin/c7.png","assets/coin/c8.png","assets/coin/c9.png",
"assets/coin/c10.png")
pumkinImg=loadAnimation("assets/pumkin/po.png","assets/pumkin/po2.png")
w1=loadAnimation("assets/witch1/w1.png","assets/witch1/w2.png","assets/witch1/w3.png","assets/witch1/w4.png","assets/witch1/w5.png","assets/witch1/w6.png")
w2=loadAnimation("assets/witch2/w1.png","assets/witch2/w2.png","assets/witch2/w3.png","assets/witch2/w4.png")
knightImg=loadAnimation("assets/knight/k1.png","assets/knight/k2.png","assets/knight/k3.png","assets/knight/k4.png",
"assets/knight/k5.png","assets/knight/k6.png")
d=loadAnimation("assets/dragon/g1.png","assets/dragon/g2.png","assets/dragon/g3.png","assets/dragon/g4.png","assets/dragon/g5.png","assets/dragon/g6.png","assets/dragon/g7.png","assets/dragon/g8.png","assets/dragon/g9.png","assets/dragon/g10.png","assets/dragon/g11.png","assets/dragon/g12.png","assets/dragon/g13.png","assets/dragon/g14.png")
c=loadAnimation("assets/cactus/c1.png","assets/cactus/c2.png","assets/cactus/c3.png","assets/cactus/c4.png","assets/cactus/c5.png")
metal=loadAnimation("assets/metal/m1.png","assets/metal/m2.png","assets/metal/m3.png","assets/metal/m4.png")
monster=loadAnimation("assets/mummy/m1.png","assets/mummy/m2.png","assets/mummy/m3.png","assets/mummy/m4.png","assets/mummy/m5.png")
saw=loadImage("assets/saw.png")
gateImage=loadImage("assets/gate.png")
girlStop=loadAnimation("assets/girl/g3.png")

}


function setup(){
    createCanvas(displayWidth,displayHeight);
    girl = createSprite(350,displayHeight-170,40,100);
    girl.addAnimation("run",girlAn)
    girl.addAnimation("stap",girlStop)
    girl.addAnimation("knight",knightImg)
    girl.scale=0.3;
   girl.setCollider("circle",0,260,150)
   //girl.debug=true
    ground= createSprite(0,500,displayWidth,displayHeight);
    ground.addAnimation("bg1",bg1)
    ground.addAnimation("bg2",bg2)
    ground.addAnimation("bg3",bg3)
    ground.velocityX=-3
    ground.depth=girl.depth
    girl.depth+=1;
invGround=createSprite(0,displayHeight-20,displayWidth,5)
invGround.visible=false
halloObsGroup=new Group()
jungleObsGroup=new Group()
dungeonObsGroup=new Group()
gatesGroup=new Group()
coinsGroup=new Group()
gemGroup=new Group()

}

function draw(){
    background(0);
    ground.velocityX=-3
   if(gameState===0){

    sound1.play()
    halloweenObs()
   }
else if(gameState===1)
{
        sound2.play()
        ground.changeAnimation("bg2",bg2)
        jungleObs()  

}
else if(gameState===2)
{
        sound3.play()
        ground.changeAnimation("bg3",bg3)
        girl.changeAnimation("knight",knightImg)
        dungeonObs()  

}
if(keyDown("space")){
        girl.velocityY=-10
}
    girl.velocityY+=1
    if(ground.x<displayWidth){
        ground.x=ground.width/2;
    }
    
    if(halloObsGroup.isTouching(girl) || jungleObsGroup.isTouching(girl) || dungeonObsGroup.isTouching(girl)  )
    {
           girl.changeAnimation("stap",girlStop)
            halloObsGroup.setVelocityXEach(0);
            jungleObsGroup.setVelocityXEach(0)
            dungeonObsGroup.setVelocityXEach(0)
            gatesGroup.setVelocityXEach(0)
            ground.velocityX=0
    }
if(gatesGroup.isTouching(girl))
{
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: gameState=0
                  break;
          case 2: gameState=1;
                  break;
          case 3: gameState=2
                  break;
          default: break;
        }
          
}
if(gemGroup.isTouching(girl) || coinsGroup.isTouching(girl)) {
        coinSound.play()
        gemGroup.destroyEach()
        coinsGroup.destroyEach()
}
    drawSprites();
     gates()
     gems()
     coins()
     girl.collide(invGround)
      

}


function halloweenObs(){
    if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",w1);
                  break;
          case 2: obstacle.addAnimation("obstacle2",w2);
                  break;
          case 3: obstacle.addAnimation("obstacle3",pumkinImg);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 1.1;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        halloObsGroup.add(obstacle);
      }

}

function jungleObs(){
    if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",c);
                  break;
          case 2: obstacle.addAnimation("obstacle2",metal);
                  break;
          case 3: obstacle.addImage("obstacle3",saw);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 0.5;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        jungleObsGroup.add(obstacle);
        jungleObstaclesGroup.add(obstacle);
      }

    
}

function dungeonObs(){
if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",mummy);
                  break;
          case 2: obstacle.addAnimation("obstacle2",monster);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 0.4;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        dungeonObsGroup.add(obstacle);
      }
}   
function gates(){
    if(frameCount % 600 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-70,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        obstacle.addImage("gate",gateImage)
        obstacle.scale=0.5
        //assign scale and lifetime to the obstacle           
        
        obstacle.lifetime = 900;
        gatesGroup.add(obstacle)
      }
}

function gems(){
        if(frameCount % 500 === 0) {
            var gem = createSprite(displayWidth,displayHeight-50,40,40);
            //obstacle.debug = true;
            gem.velocityX = -6;
        gem.addAnimation("gem",gemImage)
           gem.scale=0.3
            //assign scale and lifetime to the obstacle           
            
            gem.lifetime = 900;
            gemGroup.add(gem)
          }
    }

    function coins(){
        if(frameCount % 50 === 0) {
            var coin = createSprite(displayWidth,displayHeight-50,40,40);
            //obstacle.debug = true;
            coin.velocityX = -6;
        coin.addAnimation("coin",coinsImg)
           coin.scale=0.3
            //assign scale and lifetime to the obstacle           
            
            coin.lifetime = 900;
            coinsGroup.add(coin)
          }

          if(obstaclesGroup.isTouching(trex)){
                gameState = END;
              
            }
          }
           else if (gameState === END) {
              ground.velocityX = 0;
             trex.changeAnimation("collided" , trex_collided)
             obstaclesGroup.setVelocityXEach(0);
             cloudsGroup.setVelocityXEach(0);
             
             gameOver.visible = true;
            restart.visible = true;
             
             
            obstaclesGroup.setLifetimeEach(-1);
             cloudsGroup.setLifetimeEach(-1);
             
            trex.velocityY = 0; 
           }
          
         
          //stop trex from falling down
          trex.collide(invisibleGround);

          gameOver() {
                swal({
                  title: `Game Over`,
                  text: "Oops you lost the race....!!!",
                  imageUrl:
                    "https://cdn.shopify.com/s/files/1/1061/1924/products/Thumbs_Down_Sign_Emoji_Icon_ios10_grande.png",
                  imageSize: "100x100",
                  confirmButtonText: "Thanks For Playing"
                });
              }
            }
            
         
          }
    }